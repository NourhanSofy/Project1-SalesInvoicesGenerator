package Controller;
import Model.HeaderTableM;
import Model.InvoiceHeader;
import Model.InvoiceLine;
import Model.LineTableModel;
import view.InvoiceHDialog;
import view.InvoiceLDialog;
import view.InvoicesFrame;
import javax.swing.*;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.*;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;


public class InvoicesController implements ActionListener, ListSelectionListener {


    private InvoiceHDialog headerD;
    private InvoicesFrame f;
    private InvoiceLDialog lineD;

    public InvoicesController  (InvoicesFrame frame) {
        this.f = frame;
    }

    @Override
    public void valueChanged(ListSelectionEvent e) {
        int selectedRow = f.getInvoicesTable().getSelectedRow();
        if (selectedRow == -1) {
            f.getInvNumLbl().setText("");
            f.getCustNameLbl().setText("");
            f.getInvDateLbl().setText("");
            f.setLineTableModel(new LineTableModel());
            f.getInvTotalLbl().setText("");
        } else {
            InvoiceHeader selectedInvoice = f.getInvoices().get(selectedRow);
            f.getCustNameLbl().setText(selectedInvoice.getName());
            f.getInvNumLbl().setText("" + selectedInvoice.getNum());
            f.getInvTotalLbl().setText("" + selectedInvoice.getTotal());
            f.getInvDateLbl().setText(f.sdf.format(selectedInvoice.getDate()));
            f.setLineTableModel(new LineTableModel(selectedInvoice.getLines()));
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String action = e.getActionCommand();
        switch (action) {
            case "New Invoice":
                newInvoice();
                break;

            case "Delete Invoice":
                deleteInvoice();
                break;

            case "New Item":
                newItem();
                break;

            case "Delete Item":
                deleteItem();
                break;

            case "Load Files":
                loadFiles(null, null);
                break;

            case "Save Data":
                saveData();
                break;

            case "newInvoiceOK":
                newInvOK();
                break;

            case "newInvoiceCancel":
                newInvCancel();
                break;

            case "newLineOK":
                newLOK();
                break;

            case "newLineCancel":
                newLCancel();
                break;
        }
    }

    private void newInvoice() {
        headerD = new InvoiceHDialog(f);
        headerD.setVisible(true);
    }

    private void deleteInvoice() {
        int row = f.getInvoicesTable().getSelectedRow();
        if (row != -1) {
            f.getInvoices().remove(row);
            f.getHeaderTableModel().fireTableDataChanged();
        }
    }

    private void newItem() {
        int selectedInv = f.getInvoicesTable().getSelectedRow();
        if (selectedInv == -1) {
            JOptionPane.showMessageDialog(f, "Please select Invoice to add item ", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            lineD = new InvoiceLDialog(f);
            lineD.setVisible(true);
        }
    }

    private void deleteItem() {
        int selectedInv = f.getInvoicesTable().getSelectedRow();
        int selectedItem = f.getItemsTable().getSelectedRow();
        if (selectedInv != -1 && selectedItem != -1) {
            InvoiceHeader invoice = f.getInvoices().get(selectedInv);
            invoice.getLines().remove(selectedItem);
            f.getLineTableModel().fireTableDataChanged();
            f.getHeaderTableModel().fireTableDataChanged();
            f.getInvoicesTable().setRowSelectionInterval(selectedInv, selectedInv);
        }
    }

    public void loadFiles(String path1, String path2) {
        File hFile = null;
        File lFile = null;
        if (path1 == null && path2 == null) {
            JFileChooser file = new JFileChooser();
            JOptionPane.showMessageDialog(f, "Please, select Header file!", "Header", JOptionPane.WARNING_MESSAGE);
            int result = file.showOpenDialog(f);
            if (result == JFileChooser.APPROVE_OPTION) {
                hFile = file.getSelectedFile();
                JOptionPane.showMessageDialog(f, "Please, select Line file!", "Line", JOptionPane.WARNING_MESSAGE);
                result = file.showOpenDialog(f);
                if (result == JFileChooser.APPROVE_OPTION) {
                    lFile = file.getSelectedFile();
                }
            }
        } else {
            hFile = new File(path1);
            lFile = new File(path2);
        }

        if (hFile != null && lFile != null) {
            try {
                List<String> hData = readFile(hFile);
                List<String> lData = readFile(lFile);
                f.getInvoices().clear();

                for (String header : hData) {
                    String[] segments = header.split(",");
                    int num = (int) Integer.parseInt(segments[0]);
                    Date date = new Date();
                    try {
                        date = f.sdf.parse(segments[1]);
                    } catch (ParseException ex) {
                        JOptionPane.showMessageDialog(f, "Error while parsing date: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                    }
                    String name = segments[2];
                    InvoiceHeader inv = new InvoiceHeader(num, date, name);
                    f.getInvoices().add(inv);
                }
                f.setHeaderTableModel(new HeaderTableM(f.getInvoices()));

                for (String line : lData) {
                    String[] segments = line.split(",");
                    int num = Integer.parseInt(segments[0]);
                    String name = segments[1];
                    int price = Integer.parseInt(segments[2]);
                    int count = Integer.parseInt(segments[3]);
                    InvoiceHeader invoice = f.getInvoiceByNum(num);
                    InvoiceLine invLine = new InvoiceLine(name, price, count, invoice);
                }

            } catch (IOException ex) {
                JOptionPane.showMessageDialog(f, "Error while reading data: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        }
    }


    private List<String> readFile(File f) throws IOException {
        FileReader file = new FileReader(f);
        BufferedReader br = new BufferedReader(file);
        List<String> lines = new ArrayList<>();
        String line = null;

        while ((line = br.readLine()) != null) {
            lines.add(line);
        }

        return lines;
    }

    private void newInvOK() {
        try {
            String dateStr = headerD.getInvDateField().getText();
            String name = headerD.getCustNameField().getText();

            Date date = f.sdf.parse(dateStr);
            int num = f.getNextInvoiceNum();
            InvoiceHeader inv = new InvoiceHeader(num, date, name);
            f.getInvoices().add(inv);
            f.getHeaderTableModel().fireTableDataChanged();
            newInvCancel();
        } catch (ParseException ex) {
            JOptionPane.showMessageDialog(f, "Error in Date format", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void newInvCancel() {
        headerD.setVisible(false);
        headerD.dispose();
        headerD = null;
    }

    private void newLOK() {
        String name = lineD.getItemNameField().getText();
        int count = Integer.parseInt(lineD.getItemCountField().getText());
        int price = Integer.parseInt(lineD.getItemPriceField().getText());
        int selectedInvIndex = f.getInvoicesTable().getSelectedRow();
        InvoiceHeader inv = f.getInvoices().get(selectedInvIndex);

        new InvoiceLine(name, price, count, inv);
        f.getHeaderTableModel().fireTableDataChanged();
        f.getInvoicesTable().setRowSelectionInterval(selectedInvIndex, selectedInvIndex);
        newLCancel();
    }

    private void newLCancel() {
        lineD.setVisible(false);
        lineD.dispose();
        lineD = null;
    }
    private void saveData() {
        JFileChooser fc = new JFileChooser();
        File hFile = null;
        File lFile = null;

        JOptionPane.showMessageDialog(f, "Please, select new file to save Header information", "Header", JOptionPane.QUESTION_MESSAGE);
        int selected = fc.showSaveDialog(f);
        if (selected == JFileChooser.APPROVE_OPTION) {
            hFile = fc.getSelectedFile();
            JOptionPane.showMessageDialog(f, "Please, select new file to save Item information", "Header", JOptionPane.QUESTION_MESSAGE);
            selected = fc.showSaveDialog(f);
            if (selected == JFileChooser.APPROVE_OPTION) {
                lFile = fc.getSelectedFile();
            }
        }

        if (hFile != null && lFile != null) {
            String hinfo = "";
            String linfo = "";

            for (InvoiceHeader inv : f.getInvoices()) {
                hinfo += inv.getcsvH();
                hinfo += "\n";
                for (InvoiceLine line : inv.getLines()) {
                    linfo += line.getcsvL();
                    linfo += "\n";
                }
            }
            try {
                FileWriter hfilewriter = new FileWriter(hFile);
                FileWriter lfilewriter = new FileWriter(lFile);

                hfilewriter.write(hinfo);
                lfilewriter.write(linfo);

                hfilewriter.flush();
                lfilewriter.flush();

                hfilewriter.close();
                lfilewriter.close();

            } catch (Exception ex) {

            }
        }
    }
}


