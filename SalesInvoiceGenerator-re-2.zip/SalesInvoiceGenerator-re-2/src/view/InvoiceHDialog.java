package view;

import javax.swing.*;
import java.awt.*;

public class InvoiceHDialog extends JDialog {
    private JTextField custName;
    private JTextField invDate;
    private JLabel custNameLbl;
    private JLabel invDateLbl;
    private JButton okBtn;
    private JButton cancelBtn;

    public InvoiceHDialog (InvoicesFrame frame) {
        custNameLbl = new JLabel("Customer Name:");
        custName = new JTextField(20);
        invDateLbl = new JLabel("Invoice Date:");
        invDate = new JTextField(20);
        okBtn = new JButton("OK");
        cancelBtn = new JButton("Cancel");

        okBtn.setActionCommand("newInvoiceOK");
        cancelBtn.setActionCommand("newInvoiceCancel");

        okBtn.addActionListener(frame.getController());
        cancelBtn.addActionListener(frame.getController());
        setLayout(new GridLayout(3, 2));

        add(invDateLbl);
        add(invDate);
        add(custNameLbl);
        add(custName);
        add(okBtn);
        add(cancelBtn);
        setModal(true);
        pack();

    }

    public JTextField getCustNameField() {
        return custName;
    }

    public JTextField getInvDateField() {
        return invDate;
    }

}
